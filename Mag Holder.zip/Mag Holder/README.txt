uses gen 5 or equivalent size coil spring for lock bar
mag catch spring will need to be cut 10.5mm for the short version